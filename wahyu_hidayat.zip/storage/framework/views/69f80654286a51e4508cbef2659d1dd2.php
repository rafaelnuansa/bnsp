

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Daftar Barang</div>

                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <a href="<?php echo e(route('barang.create')); ?>" class="btn btn-primary mb-3">Tambah Barang</a>

                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Kode Barang</th>
                                    <th scope="col">Nama Barang</th>
                                    <th scope="col">Harga Jual</th>
                                    <th scope="col">Harga Beli</th>
                                    <th scope="col">Satuan</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($barang->kode_barang); ?></td>
                                        <td><?php echo e($barang->nama_barang); ?></td>
                                        <td><?php echo e($barang->harga_jual); ?></td>
                                        <td><?php echo e($barang->harga_beli); ?></td>
                                        <td><?php echo e($barang->satuan); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('barang.show', $barang->id)); ?>" class="btn btn-info btn-sm">Detail</a>
                                            <a href="<?php echo e(route('barang.edit', $barang->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                            <form action="<?php echo e(route('barang.destroy', $barang->id)); ?>" method="POST" style="display: inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus barang ini?')">Hapus</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BNSP\rafael_nuansa\resources\views/barang/index.blade.php ENDPATH**/ ?>