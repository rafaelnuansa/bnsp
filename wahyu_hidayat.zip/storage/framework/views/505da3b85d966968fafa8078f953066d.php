

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Daftar Penjualan</div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <a href="<?php echo e(route('penjualan.create')); ?>" class="btn btn-primary mb-3">Tambah Penjualan Baru</a>

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col">No Faktur</th>
                                <th scope="col">Tanggal Faktur</th>
                                <th scope="col">Nama Konsumen</th>
                                <th scope="col">Kode Barang</th>
                                <th scope="col">Jumlah</th>
                                <th scope="col">Harga Satuan</th>
                                <th scope="col">Harga Total</th>
                                <th scope="col">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $penjualans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penjualan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($penjualan->no_faktur); ?></td>
                                <td><?php echo e($penjualan->tgl_faktur); ?></td>
                                <td><?php echo e($penjualan->nama_konsumen); ?></td>
                                <td><?php echo e($penjualan->kode_barang); ?></td>
                                <td><?php echo e($penjualan->jumlah); ?></td>
                                <td><?php echo e($penjualan->harga_satuan); ?></td>
                                <td><?php echo e($penjualan->harga_total); ?></td>
                                <td>
                                    <a href="<?php echo e(route('penjualan.show', $penjualan->id)); ?>" class="btn btn-info btn-sm">Detail</a>
                                    <a href="<?php echo e(route('penjualan.edit', $penjualan->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                    <form action="<?php echo e(route('penjualan.destroy', $penjualan->id)); ?>" method="POST" style="display: inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BNSP\rafael_nuansa\resources\views/penjualan/index.blade.php ENDPATH**/ ?>