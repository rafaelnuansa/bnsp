

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Penjualan</div>

                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('penjualan.update', $penjualan->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group">
                            <label for="tgl_faktur">Tanggal Faktur</label>
                            <input type="date" class="form-control" id="tgl_faktur" name="tgl_faktur" value="<?php echo e($penjualan->tgl_faktur); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="no_faktur">No Faktur</label>
                            <input type="text" class="form-control" id="no_faktur" name="no_faktur" value="<?php echo e($penjualan->no_faktur); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="nama_konsumen">Nama Konsumen</label>
                            <input type="text" class="form-control" id="nama_konsumen" name="nama_konsumen" value="<?php echo e($penjualan->nama_konsumen); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="kode_barang">Pilih Barang</label>
                            <select class="form-control" id="kode_barang" name="kode_barang" required>
                                <option value="">Pilih Barang</option>
                                <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($barang->kode_barang); ?>" <?php echo e($barang->kode_barang == $penjualan->kode_barang ? 'selected' : ''); ?> data-harga="<?php echo e($barang->harga_jual); ?>">
                                        <?php echo e($barang->nama_barang); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="jumlah">Jumlah</label>
                            <input type="number" class="form-control" id="jumlah" name="jumlah" value="<?php echo e($penjualan->jumlah); ?>" required>
                        </div>

                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BNSP\rafael_nuansa\resources\views/penjualan/edit.blade.php ENDPATH**/ ?>